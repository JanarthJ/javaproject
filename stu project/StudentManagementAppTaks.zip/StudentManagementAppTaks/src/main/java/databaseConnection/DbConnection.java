package databaseConnection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbConnection {
	
	private static Connection connection;

	
	//singleton design pattern
	public static Connection getConnection(){
		Properties props = new Properties();
		if(connection == null) {
			try {
				FileInputStream fs = new FileInputStream("C:\\Users\\Lalith kumar A\\eclipse-workspace\\StudentManagementAppTaks\\src\\main\\resources\\config.properties");
				props.load(fs);
				String dbDriver = props.getProperty("ds.db-Driver");
				String dbUrl = props.getProperty("ds.db-Url");
				String dbUsername = props.getProperty("ds.db-Username");
				String dbPassword = props.getProperty("ds.db-Password");
				
				if(dbDriver == null || dbUrl == null || dbUsername == null || dbPassword == null) {
					throw  new IllegalArgumentException("one of the field is empty");
				}else {
					Class.forName(dbDriver);
					connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
				}
				
			} catch (FileNotFoundException e) {
				System.out.println(e);
			}catch(IOException err) {
				System.out.println(err);
			}catch(ClassNotFoundException error) {
				System.out.println(error);
			}catch(SQLException er) {
				System.out.println(er);
			}
		}
		return connection;
	}
}
