/**
 * 
 */
/**
 * 
 */
module designPatterns {
}