package testing;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class JunitTesting {
	
	@Before
	public void display() {
		System.out.println("Hello...Test case started...");
	}
	
	@After
	public void displayAfter() {
		System.out.println("Byee...Test case ended...");
	}
	
	@Test
	public void check() {
		assertTrue(10>2);
		assertFalse(1>100);
		assertEquals(10,12-2);
		
	}

}
