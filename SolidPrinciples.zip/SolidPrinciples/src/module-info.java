/**
 * 
 */
/**
 * 
 */
module SolidPrinciples {
}