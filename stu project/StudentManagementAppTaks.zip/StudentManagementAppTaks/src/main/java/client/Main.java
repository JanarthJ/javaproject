package client;

import java.util.List;
import java.util.Scanner;

import model.StudentAppTask;
import service.StudentAppTaskService;



public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
			
		
				Scanner sc = new Scanner(System.in);
				
				int choice;
				do {
					System.out.println(" \nHey User...WELCOME TO STUDENT MANAGEMENT APP");
					System.out.println("Here some Operations... ");
					System.out.println("1. Fetch Student Detail By Roll NO.");
					System.out.println("2. Fetch Student Detail By Major.(cse,ece,civil)");
					System.out.println("3. Fetch Student Detail By Mark.(95,93,90,87)");
					System.out.println("4. Fetch All Student Detail.");
					System.out.println("5. Exit.");
					System.out.print("Please Enter Your choice to Proceed Further : ");
					choice = sc.nextInt();
					StudentAppTaskService stuservice = new StudentAppTaskService();
					switch(choice) {
					
					case 1:
						try {
							System.out.println("Enter rollno to get Student details : ");
							int rollno = sc.nextInt();
							StudentAppTask result = stuservice.getStudentByRollNO(rollno); 
							
							System.out.println("Student Name : " + result.getStd_name());
							System.out.println("Student Major : " + result.getMajor());
							System.out.println("Student Mark : " + result.getMark());
						}catch(Exception e) {
							throw new Exception("No Student Found with Roll No...");
						}
							break;
					case 2:
						try {
							System.out.println("Enter major to get Student details : ");
							String major = sc.next();
							StudentAppTask result = stuservice.getStudentByMajor(major); 
							
							System.out.println("Student Roll No : " + result.getRollno());
							System.out.println("Student Name : " + result.getStd_name());
							System.out.println("Student Mark : " + result.getMark());
						}catch(Exception e) {
							throw new Exception("No Student Found with major...");
						}
							break;
					case 3:
						try {
							System.out.println("Enter mark to get Student details : ");
							int mark = sc.nextInt();
							StudentAppTask result = stuservice.getStudentByMark(mark); 
							
							System.out.println("Student Roll No : " + result.getRollno());
							System.out.println("Student Name : " + result.getStd_name());
							System.out.println("Student Major : " + result.getMajor());
						}catch(Exception e) {
							throw new Exception("No Student Found with mark...");
						}
							break;					
					case 4:
						try {
							List<StudentAppTask> res = stuservice.getStudentAllDetails();
							for (StudentAppTask s : res) {
								System.out.println("Student ID : "+s.getRollno());
								System.out.println("Student Name : "+s.getStd_name());
								System.out.println("Student Major : "+s.getMajor());
								System.out.println("Student Mark : "+s.getMark());
								System.out.println();
							}
						}catch(Exception e) {
							throw new Exception("No Student Found..");
						}							
						break;
					case 5:
						break;
					default:
						System.out.println("enter correct valid choice....");
					}
					
			}while(choice != 5);
					System.out.println("Thank you for using our service.....");
			
				
				sc.close();

	}
	
}
