package com.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Student {
    private int id;
    private String name;
    private String email;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}

public interface StudentDAO {
    List<Student> getAllStudents();
    Student getStudentById(int id);
    boolean addStudent(Student student);
    boolean updateStudent(Student student);
    boolean deleteStudent(int id);
}

public class StudentDAOImpl implements StudentDAO {
    private static StudentDAOImpl instance;

    private StudentDAOImpl() {
    }

    public static StudentDAOImpl getInstance() {
        if (instance == null) {
            instance = new StudentDAOImpl();
        }
        return instance;
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM students");
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Student student = new Student();
                student.setId(resultSet.getInt("id"));
                student.setName(resultSet.getString("name"));
                student.setEmail(resultSet.getString("email"));
                students.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    @Override
    public Student getStudentById(int id) {
        Student student = null;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM students WHERE id = ?")) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                student = new Student();
                student.setId(resultSet.getInt("id"));
                student.setName(resultSet.getString("name"));
                student.setEmail(resultSet.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
    }

    @Override
    public boolean addStudent(Student student) {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO students (id, name, email) VALUES (?, ?, ?)")) {
            statement.setInt(1, student.getId());
            statement.setString(2, student.getName());
            statement.setString(3, student.getEmail());
            int rowsInserted = statement.executeUpdate();
            return rowsInserted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
       
    }

    @Override
    public boolean updateStudent(Student student) {
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE students SET name = ?, email = ? WHERE id = ?")) {
            statement.setString(1, student.getName());
            statement.setString(2, student.getEmail());
            statement.setInt(3, student.getId());
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteStudent(int id) {
       try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "DELETE FROM students WHERE id = ?")) {
            statement.setInt(1, id);
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
public interface ReadableStudentDAO {
    List<Student> getAllStudents();
    Student getStudentById(int id);
}

public interface WritableStudentDAO {
    boolean addStudent(Student student);
    boolean updateStudent(Student student);
    boolean deleteStudent(int id);
}

public class StudentDAOImpl implements ReadableStudentDAO, WritableStudentDAO {
    private final DatabaseManager dbManager;

    public StudentDAOImpl(DatabaseManager dbManager) {
        this.dbManager = dbManager;
    }

    @Override
    public List<Student> getAllStudents() {
        return dbManager.getAllStudents();
    }

    @Override
    public Student getStudentById(int id) {
        return dbManager.getStudentById(id);
    }

    @Override
    public boolean addStudent(Student student) {
        return dbManager.addStudent(student);
    }

    @Override
    public boolean updateStudent(Student student) {
        return dbManager.updateStudent(student);
    }

    @Override
    public boolean deleteStudent(int id) {
        return dbManager.deleteStudent(id);
    }
}

public List<Student> getAllStudents() {
    List<Student> students = new ArrayList<>();
    try (Connection connection = getConnection();
         PreparedStatement statement = connection.prepareStatement("SELECT * FROM students");
         ResultSet resultSet = statement.executeQuery()) {
        while (resultSet.next()) {
            Student student = new Student();
            student.setId(resultSet.getInt("id"));
            student.setName(resultSet.getString("name"));
            student.setEmail(resultSet.getString("email"));
            students.add(student);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return students;
}
public Student getStudentById(int id) {
    Student student = null;
    try (Connection connection = getConnection();
         PreparedStatement statement = connection.prepareStatement("SELECT * FROM students WHERE id = ?")) {
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            student = new Student();
            student.setId(resultSet.getInt("id"));
            student.setName(resultSet.getString("name"));
            student.setEmail(resultSet.getString("email"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return student;
}


    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/mine";
        String username = "minee";
        String password = "mine";
        return DriverManager.getConnection(url, username, password);
        return null;
    }
}

public class StudentDAOImplTest {
    @Test
    public void testGetAllStudents() {
        StudentDAO studentDAO = StudentDAOImpl.getInstance();
        List<Student> students = studentDAO.getAllStudents();
        assertEquals(3, students.size());
    }

    @Test
    public void testGetStudentById() {
        StudentDAO studentDAO = StudentDAOImpl.getInstance();
        Student student = studentDAO.getStudentById(1);
        assertEquals("John", student.getName());
    }
}


