package dao
;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import databaseConnection.DbConnection;
import model.StudentAppTask;

public class StudentAppTaskDAO {

	private Connection Db;
	public StudentAppTaskDAO() {
		
		Db = DbConnection.getConnection();
		System.out.println("Connected to Student DataBase");
	}
	
	public StudentAppTask getStudentRollno(int rollno) {
		
		StudentAppTask stu = null;
		
		try {
			String query = "SELECT * FROM students WHERE rollno = ?";
			PreparedStatement ps = Db.prepareStatement(query);
			ps.setInt(1,rollno);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				stu = new StudentAppTask();
				stu.setStd_name(rs.getString("stu_name"));
				stu.setMajor(rs.getString("major"));
				stu.setMark(rs.getInt("mark"));
			}
		
		}catch(SQLException e) {
			System.out.println("ERROR OCCURED : " + e);
		}
		
		return stu;
	}
	
	public StudentAppTask getStudentMajor(String major) {
			
			StudentAppTask stu1 = null;
			
			try {
				String query = "SELECT * FROM students WHERE major = ?";
				PreparedStatement ps = Db.prepareStatement(query);
				ps.setString(1,major);
				
				ResultSet rs = ps.executeQuery();
				
				while(rs.next()) {
					stu1 = new StudentAppTask();
					stu1.setRollno(rs.getInt("rollno"));
					stu1.setStd_name(rs.getString("stu_name"));
					stu1.setMark(rs.getInt("mark"));
				}
			
			}catch(SQLException e) {
				System.out.println("ERROR OCCURED : " + e);
			}
			
			return stu1;
		}
	
	public StudentAppTask getStudentMark(int mark) {
		
		StudentAppTask stu2 = null;
		
		try {
			String query = "SELECT * FROM students WHERE mark = ?";
			PreparedStatement ps = Db.prepareStatement(query);
			ps.setInt(1,mark);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				stu2 = new StudentAppTask();
				stu2.setRollno(rs.getInt("rollno"));
				stu2.setStd_name(rs.getString("stu_name"));
				stu2.setMajor(rs.getString("major"));
			}
		
		}catch(SQLException e) {
			System.out.println("ERROR OCCURED : " + e);
		}
		
		return stu2;
	}
	
	public List<StudentAppTask> getStudentDetails(){
		List<StudentAppTask> students = new ArrayList<>();
		
		try {
			String query1 = "SELECT * FROM students";
			PreparedStatement ps1 = Db.prepareStatement(query1);
			
			ResultSet rs1 = ps1.executeQuery();
			while(rs1.next()) {
				StudentAppTask stud = new StudentAppTask();
				stud.setRollno(rs1.getInt("rollno"));
				stud.setStd_name(rs1.getString("stu_name"));
				stud.setMajor(rs1.getString("major"));
				stud.setMark(rs1.getInt("mark"));
				
				students.add(stud);
			}
			
		}catch(SQLException e) {
			System.out.println("ERROR : " + e);
		}
		
		return students;
	}
	
}
