package service;

import java.util.List;

import dao.StudentAppTaskDAO;
import model.StudentAppTask;

public class StudentAppTaskService {

	private StudentAppTaskDAO dl;
	public StudentAppTaskService() {
		this.dl = new StudentAppTaskDAO();
	}
	
	public StudentAppTask getStudentByRollNO(int rollno) {
		 return dl.getStudentRollno(rollno);
		
	}
	
	public StudentAppTask getStudentByMajor(String major) {
		 return dl.getStudentMajor(major);
		
	}
	
	public StudentAppTask getStudentByMark(int mark) {
		 return dl.getStudentMark(mark);
		
	}
	
	public List<StudentAppTask> getStudentAllDetails() {
		 return dl.getStudentDetails();
		
	}
}
